---
title: Arrow left-short
categories:
  - Arrows
tags:
  - arrow
---
